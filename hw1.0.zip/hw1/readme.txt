******************************************
SCU ID: W1105440
SCU email: abirjepatil@scu.edu
Name: Abhishek Birjepatil
Project Name: hw1
Package Name: com.scu.abirjepatil
IDE Used: Eclipse.

List of files.
1.Applications.java
2.Students.java
3.output.txt
4.readme.txt
******************************************

How to Execute on Command Line:
1. javac *.java
2. java Application
******************************************