//package com.scu.abirjepatil;
class Students
{
	static int count=0;
	//student class with id name and imgLocation.
	int ID;
	String name;
	String imgLocation;
	/*
	 * 
	 *  public Student() -- this constructor
	 *  should initialize the student name to be 
	 *  the empty string, the ID to be -1, and the 
	 *  filename to be the empty string.
	 */
	public Students()
	{
		count++;
		this.ID=-1;
		this.name="";
		this.imgLocation="";
		
	}
	/*
	 * public Student(String n, int ID, String filename) -- 
	 * should initialize the corresponding fields in the class.
	 * 
	 */
	Students(int ID,String name,String filename)
	{
		count++;
		this.ID=ID;
		this.name=name;
		this.imgLocation=filename;
	}
	//setter method 
	public void setStudent(int ID,String name,String filename)
	{
		this.ID=ID;
		this.name=name;
		this.imgLocation=filename;
	}
	//getter method
	public Students getStudent()
	{
		Students s= new Students();
		s.ID=this.ID;
		s.name=this.name;
		s.imgLocation=this.imgLocation;
		return s;
		
	}
	

}

